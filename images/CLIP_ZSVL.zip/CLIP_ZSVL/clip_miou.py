import torch
import clip
from PIL import Image
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

def decod_one_image_query_forward(model, preprocess, device, img_path_list, query):
    """
    input a img path list
    query: list of sentence
    """    
    images = []
    for img_path in img_path_list:
        image = preprocess(Image.open(img_path)).unsqueeze(0)
        images.append(image)
    images = torch.cat(images, 0).to(device)
    text = clip.tokenize(query).to(device)

    with torch.no_grad():
        image_features = model.encode_image(images)
        text_features = model.encode_text(text)
        # normalized features
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)


        # cosine similarity as logits
        logit_scale = model.logit_scale.exp()
        logits_per_image = logit_scale * image_features @ text_features.t()
        logits_per_text = logits_per_image.t()
    return logits_per_text.squeeze().cpu().numpy()

def generate_gt_mask(start_time, end_time, fps, num_frames):
    gt_mask = np.zeros(num_frames)
    start_index = int(start_time*fps)
    end_index = int(end_time*fps)
    gt_mask[start_index:end_index+1] = 1
    return torch.from_numpy(gt_mask)

def get_iou(mask1, mask2):
    """
    Input torch tensor
    """
    intersect = (mask1 * mask2).sum()
    union = (mask1 + mask2).sum() - intersect
    return intersect / union

#load CLIP
device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/32", device=device)


#7UPGT 13.9 19.7##person takes a cup out the fridge.
#IGDIE 22.7 34.0##person starts watching television.
query_labels = ['IGDIE 22.7 34.0##person starts watching television.', '7UPGT 13.9 19.7##person takes a cup out the fridge.']
query_labels = Path('/new_share/yulu/CLIP_ZSVL/datas/charades/annotations/charades_sta_test.txt').read_text().split('\n')[:-1]
ious = []
R1 = []
R3 = []
R5 = []
R7 = []
tbar = tqdm(query_labels)
for query_label in tbar:
    query = query_label.split('##')[1]
    vid_id, start_time, end_time = query_label.split('##')[0].split(' ')
    img_path_lists = sorted((Path('/new_share/yulu/CLIP_ZSVL/datas/charades/frames') / vid_id).iterdir())
    y = decod_one_image_query_forward(model, preprocess, device, img_path_lists, query)
    x = np.arange(y.shape[0])
    gt_y = generate_gt_mask(eval(start_time), eval(end_time), 3, len(x))

    torch_y = torch.from_numpy(np.array(y)).float()
    torch_y = (torch_y - torch_y.mean()) / torch_y.var()
    torch_y = torch_y.float().sigmoid()
    torch_y = torch.where(torch_y>0.5, 1, 0)

    iou = get_iou(torch_y, gt_y)
    ious.append(iou)
    R1.append(iou>0.1)
    R3.append(iou>0.3)
    R5.append(iou>0.5)
    R7.append(iou>0.7)
    tbar.set_description(f'vid: {vid_id}, iou: {iou:.3f}, mIoU:{np.array(ious).mean():.3f}, \
    R@0.1:{np.array(R1).mean():.3f}, R@0.3:{np.array(R3).mean():.3f}, R@0.5:{np.array(R5).mean():.3f}, \
    R@0.7:{np.array(R7).mean():.3f}')
print(np.array(ious).mean())
print(np.array(R1).mean())
print(np.array(R3).mean())
print(np.array(R5).mean())
print(np.array(R7).mean())
