import torch
import clip
from PIL import Image
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

def decod_one_image_query_forward(model, preprocess, device, img_path_list, query):
    """
    input a img path list
    query: list of sentence
    """    
    images = []
    for img_path in img_path_list:
        image = preprocess(Image.open(img_path)).unsqueeze(0)
        images.append(image)
    images = torch.cat(images, 0).to(device)
    text = clip.tokenize(query).to(device)

    with torch.no_grad():
        image_features = model.encode_image(images)
        text_features = model.encode_text(text)
        # normalized features
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)


        # cosine similarity as logits
        logit_scale = model.logit_scale.exp()
        logits_per_image = logit_scale * image_features @ text_features.t()
        logits_per_text = logits_per_image.t()
    return logits_per_text.squeeze().cpu().numpy()

def generate_gt_mask(start_time, end_time, fps, num_frames):
    gt_mask = np.zeros(num_frames)
    start_index = int(start_time*fps)
    end_index = int(end_time*fps)
    gt_mask[start_index:end_index+1] = 1
    return torch.from_numpy(gt_mask)

def get_iou(mask1, mask2):
    """
    Input torch tensor
    """
    intersect = (mask1 * mask2).sum()
    union = (mask1 + mask2).sum() - intersect
    return intersect / union

#load CLIP
device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/32", device=device)


# KOVTR 10.2 19.8##person they stand up.
# KOVTR 4.2 14.2##a person awakens in their sofa.
# KOVTR 28.4 35.0##person takes some medicine.
vid_id = 'KOVTR'
duration = 35.25
fps = 3
query_labels = [{'start_time':10.2, 'end_time':19.8, 'query':'person they stand up.'}, \
{'start_time':4.2, 'end_time':14.2, 'query':'a person awakens in their sofa.'}, \
{'start_time':28.4, 'end_time':35.0, 'query':'person takes some medicine.'}]


def decod_one_proposal_query(img_path_list, query, proposal):
    """
    input a img path list
    query: list of sentence
    """    
    images = []
    for img_path in img_path_list:
        if proposal[0] <=int(img_path.stem.split('-')[1]) < proposal[1]:
            image = preprocess(Image.open(img_path)).unsqueeze(0)
            images.append(image)
    images = torch.cat(images, 0).to(device)
    text = clip.tokenize(query).to(device)

    with torch.no_grad():
        image_features = model.encode_image(images)
        text_features = model.encode_text(text)
        # normalized features
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)


        # cosine similarity as logits
        logit_scale = model.logit_scale.exp()
        logits_per_image = logit_scale * image_features @ text_features.t()
        logits_per_text = logits_per_image.t()
    return logits_per_text.squeeze().cpu().numpy()
#AMT7R 4.3 12.5##a person is putting a picture onto the wall.

proposals = [[int(x['start_time']*fps), int(x['end_time']*fps)] for x in query_labels]
querys = [x['query'] for x in query_labels]
img_path_list = sorted((Path('/new_share/yulu/CLIP_ZSVL/datas/charades/frames') / 'AMT7R').iterdir())

print(decod_one_proposal_query(img_path_list, 'a person is putting a picture onto the wall.', [4.3, 12.5]).mean())
import pdb;pdb.set_trace()






