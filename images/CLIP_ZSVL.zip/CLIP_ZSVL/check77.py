import torch
import clip
from PIL import Image
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import cv2

def get_video_tensor(video_path,preprocess):

    cap = cv2.VideoCapture(str(video_path))
    frameCount = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    #print('fps',cap.get(cv2.CAP_PROP_FPS))

    images=[]
    for idx in range(frameCount):
        success, frame = cap.read()
        if success:
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            images.append(preprocess(Image.fromarray(frame_rgb).convert("RGB")))
        else:
            break

    cap.release()

    if len(images) > 0:
        video_data = torch.tensor(np.stack(images))
    else:
        video_data = torch.Tensor(1)

    return video_data

def decod_one_image_query_forward(model, preprocess, device, video_path, query):
    """
    input a img path list
    query: list of sentence
    """    
    images = get_video_tensor(video_path, preprocess)
    if len(images) == 1:
        return torch.Tensor(1)
    else:
        images = images.to(device)
    text = clip.tokenize(query).to(device)
    if len(text)>77:
        text = text[:76]

    with torch.no_grad():
        try:
            image_features = model.encode_image(images)
        except:
            import pdb;pdb.set_trace()
        text_features = model.encode_text(text)
        # normalized features
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        text_features = text_features / text_features.norm(dim=-1, keepdim=True)


        # cosine similarity as logits
        logit_scale = model.logit_scale.exp()
        logits_per_image = logit_scale * image_features @ text_features.t()
        logits_per_text = logits_per_image.t()
    return logits_per_text.squeeze().cpu().numpy()

def generate_gt_mask(start_time, end_time, fps, num_frames):
    gt_mask = np.zeros(num_frames)
    start_index = int(start_time*fps)
    end_index = int(end_time*fps)
    gt_mask[start_index:end_index+1] = 1
    return torch.from_numpy(gt_mask)

def get_iou(mask1, mask2):
    """
    Input torch tensor
    """
    intersect = (mask1 * mask2).sum()
    union = (mask1 + mask2).sum() - intersect
    return intersect / union

def load_txt_data(txt_path):
    data_list = []
    txt_data = txt_path.read_text().split('\n')[:-1]
    for data in txt_data:
        d = {}
        query = data.split('##')[1]
        vid_id, start_time, end_time = data.split('##')[0].split(' ')

        d['vid_id'] = vid_id
        d['start_time'] = eval(start_time)
        d['end_time'] = eval(end_time)
        d['query'] = query
        data_list.append(d)
    return data_list

def load_json_data(json_path):
    data_list = []
    json_data = eval(json_path.read_text())
    # json_data = {"v_bXdq2zI1Ms0": {"duration": 73.1, "timestamps": [[0, 10.23], [10.6, 39.84], [38.01, 73.1]], "sentences": ["A man is seen speaking to the camera and pans out into more men standing behind him.", " The first man then begins performing martial arts moves while speaking to he camera.", " He continues moving around and looking to the camera."]}}
    for vid_id in json_data:
        for i in range(len(json_data[vid_id]['timestamps'])):
            d = {}
            d['vid_id'] = vid_id
            d['start_time'] = json_data[vid_id]['timestamps'][i][0]
            d['end_time'] = json_data[vid_id]['timestamps'][i][1]
            d['query'] = json_data[vid_id]['sentences'][i]
            data_list.append(d)
    return data_list

#load CLIP
device = "cuda" if torch.cuda.is_available() else "cpu"
model, preprocess = clip.load("ViT-B/32", device=device)


#7UPGT 13.9 19.7##person takes a cup out the fridge.
#IGDIE 22.7 34.0##person starts watching television.

# query_labels = Path('/new_share/yulu/CLIP_ZSVL/datas/charades/annotations/charades_sta_test.txt').read_text().split('\n')[:-1]
data_list = load_txt_data(Path('/new_share/yulu/CLIP_ZSVL/datas/charades/annotations/charades_sta_test.txt'))
data_list = load_json_data(Path('/new_share/yulu/CLIP_ZSVL/datas/activitynet/annotations/val_1.json'))

ious = []
R1 = []
R3 = []
R5 = []
R7 = []
tbar = tqdm(data_list)
for d in tbar:
    query = d['query']
    vid_id, start_time, end_time = d['vid_id'], d['start_time'], d['end_time']
    if vid_id in['v_Q-879RNVOdg', 'v_TUfYisuVrs0', 'v_81dGQTVec_s']:
        continue
    video_path = Path('/new_share/yulu/CLIP_ZSVL/datas/activitynet/compressed_videos') / (vid_id + '.mp4')
    y = decod_one_image_query_forward(model, preprocess, device, video_path, query)
    if len(y) == 1:
        continue
    x = np.arange(y.shape[0])
    gt_y = generate_gt_mask(start_time, end_time, 3, len(x))

    torch_y = torch.from_numpy(np.array(y)).float()
    torch_y = (torch_y - torch_y.mean()) / torch_y.var()
    torch_y = torch_y.float().sigmoid()
    torch_y = torch.where(torch_y>0.5, 1, 0)

    iou = get_iou(torch_y, gt_y)
    ious.append(iou)
    R1.append(iou>0.1)
    R3.append(iou>0.3)
    R5.append(iou>0.5)
    R7.append(iou>0.7)
    tbar.set_description(f'vid: {vid_id}, iou: {iou:.3f}, mIoU:{np.array(ious).mean():.3f}, \
    R@0.1:{np.array(R1).mean():.3f}, R@0.3:{np.array(R3).mean():.3f}, R@0.5:{np.array(R5).mean():.3f}, \
    R@0.7:{np.array(R7).mean():.3f}')
print(np.array(ious).mean())
print(np.array(R1).mean())
print(np.array(R3).mean())
print(np.array(R5).mean())
print(np.array(R7).mean())
