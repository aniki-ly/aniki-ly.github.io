ls -l | grep "^-" | wc -l
ls -lR | grep "^d" | wc -l
ls |head -n 10

find . -name "v_uqiMw7tQ1Cc"

tmux new -s transformer_movie_18w_2layer

Wandb Key:353fce4e4c7ce4126479b82dabd2193ae7498d04

pip install -i https://pypi.corp.kuaishou.com/root/pypi/+simple/ torch==1.5.1 torchvision yacs tqdm h5py tensorboard wandb
pip install -i https://pypi.corp.kuaishou.com/root/pypi/+simple/ opencv-python matplotlib scikit-learn

pip install -i https://pypi.corp.kuaishou.com/root/pypi/+simple/ -r requirements.txt

mkdir /tmp/empty/
rsync --delete-before -vd /tmp/empty/ PSVL_old

find . -name '*_delete.json' | xargs rm

import pdb;pdb.set_trace()
CUDA_VISIBLE_DEVICES=2 python train.py -v

tmux attach -t 0

rsync -rp -v PSVL /new_share/yulu/PSVL/

rsync -rp -v ~/.encoding/data/ data/
rsync -rp -v PSVL PSVL_baseline
rsync -rp -v 2014/ all_video
rsync -rp -v 2015/ all_video
rsync -rp -v 2016/ all_video
rsync -rp -v 2017/ all_video
rsync -rp -v 2018/ all_video
rsync -rp -v 2019/ all_video


CUDA_VISIBLE_DEVICES=4 python main_batch.py --input_file bbox_extractor/third_results_list_0.txt
python train.py --model CrossModalityTwostageAttention --config configs/cha_simple_model/simplemodel_cha_BS256_two-stage_attention.yml
python inference.py --model CrossModalityTwostageAttention --config configs/cha_simple_model/simplemodel_cha_BS256_two-stage_attention.yml --pre_trained /new_share/yulu/PSVL/checkpoints/graph_thresh1.pth


/new_share/yulu/PSVL/PSVL_env/bin/python train.py --model CrossModalityTwostageAttention --config configs/cha_simple_model/simplemodel_cha_BS256_two-stage_attention.yml

bash start.sh No

tmux split-window -h


CUDA_VISIBLE_DEVICES=2 /new_share/yulu/PSVL/PSVL_env/bin/python inference.py --model CrossModalityTwostageAttention --config configs/cha_simple_model/simplemodel_cha_BS256_two-stage_attention.yml --pre_trained VG_Shuffle

weight_decay=weight_decay=2e-05

#matplotlib
import pdb;pdb.set_trace()
x = list(range(128))
y = [time_dict[i] for i in x if i in time_dict]
plt.plot(x, y)
plt.savefig('./time_count.jpg')

python compress_videos.py --input_root videos --output_root compressed_videos